'use strict';

const root = document.documentElement;
const themeButton = document.getElementById('theme-toggle');
const themeLabel = document.getElementById('theme-label');
const themeColorMeta = document.querySelector('meta[name="theme-color"]');

function reflectTheme() {
  const dark = root.dataset.theme === 'dark';
  themeButton.setAttribute('aria-pressed', String(dark));
  themeButton.setAttribute('aria-label', dark ? 'Switch to light mode' : 'Switch to dark mode');
  themeLabel.textContent = dark ? 'Light mode' : 'Dark mode';
  themeColorMeta.setAttribute('content', dark ? '#201d1b' : '#f8f4ef');
}
reflectTheme();
themeButton.addEventListener('click', () => {
  root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark';
  try { localStorage.setItem('akhilesh-theme', root.dataset.theme); } catch (_) {}
  reflectTheme();
});

const menuButton = document.getElementById('menu-toggle');
const siteNav = document.getElementById('site-nav');
function closeMenu(returnFocus = false) {
  siteNav.classList.remove('open');
  menuButton.classList.remove('open');
  menuButton.setAttribute('aria-expanded', 'false');
  menuButton.setAttribute('aria-label', 'Open navigation menu');
  if (returnFocus) menuButton.focus();
}
menuButton.addEventListener('click', () => {
  const willOpen = !siteNav.classList.contains('open');
  siteNav.classList.toggle('open', willOpen);
  menuButton.classList.toggle('open', willOpen);
  menuButton.setAttribute('aria-expanded', String(willOpen));
  menuButton.setAttribute('aria-label', willOpen ? 'Close navigation menu' : 'Open navigation menu');
});
siteNav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => closeMenu()));
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && siteNav.classList.contains('open')) closeMenu(true);
});
document.addEventListener('click', event => {
  if (siteNav.classList.contains('open') && !siteNav.contains(event.target) && !menuButton.contains(event.target)) closeMenu();
});
window.addEventListener('resize', () => { if (innerWidth > 790) closeMenu(); }, { passive: true });

// IntersectionObserver animates once and then relinquishes the observed element.
const noMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
if ('IntersectionObserver' in window && !noMotion) {
  document.documentElement.classList.add('use-reveal');
  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        obs.unobserve(entry.target);
      }
    });
  }, { rootMargin: '0px 0px -30px 0px', threshold: 0.06 });
  document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
}

// Add understated active indication to section links.
const links = [...siteNav.querySelectorAll('a')];
if ('IntersectionObserver' in window) {
  const watched = ['about', 'projects', 'expertise', 'experience', 'contact'].map(id => document.getElementById(id));
  const activeObserver = new IntersectionObserver(entries => {
    const visible = entries.filter(x => x.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
    if (!visible) return;
    links.forEach(a => {
      const active = a.getAttribute('href') === `#${visible.target.id}`;
      a.classList.toggle('is-current', active);
      if (active) a.setAttribute('aria-current', 'location'); else a.removeAttribute('aria-current');
    });
  }, { rootMargin: '-25% 0px -60% 0px', threshold: [0, .15] });
  watched.forEach(item => activeObserver.observe(item));
}

document.getElementById('year').textContent = String(new Date().getFullYear());
