# Akhilesh Joshi — editorial portfolio (client redesign)

A simple, responsive, light/dark portfolio for Akhilesh Joshi, based on his provided resume and a warm ivory / beige editorial layout reference.

## Files
- `index.html` — the complete five-section page and resume-based content.
- `styles.css` — responsive visual styles, cream and dark themes, animations.
- `script.js` — accessible navigation, dark-mode switching with localStorage persistence, section-reveal animations.
- `favicon.svg` — custom AJ favicon.

## How to view
Open `index.html` in a browser. No build or dependencies are needed. Google Fonts is optional; the page falls back to local serif and sans-serif fonts if offline.

## How to publish
Upload all four files together to any static hosting provider (Netlify, Vercel, GitHub Pages, Hostinger, etc.). Leave the relative file paths intact.

## Sections
1. Home / hero
2. About
3. Projects — seven text-only project cards; no screenshots or images
4. Expertise + experience + education
5. Contact — email, telephone and location only; **no contact form**

## Theme
Theme is light by default to match the client's reference. The header's sun/moon button changes to dark mode; the choice is remembered with `localStorage` when available. Reduced-motion preference is respected.

## Contact
Email and phone links open the visitor's email and telephone app respectively. There is no backend or submission form.

## Content
All professional claims are sourced from the resume. Project links are copied from the resume, and their availability isn't guaranteed.
